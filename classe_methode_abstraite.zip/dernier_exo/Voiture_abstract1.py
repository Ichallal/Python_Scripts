from Vehicule_abstract1 import Vehicule

class Voiture(Vehicule):
    def __init__(self, marque, modele, annee, vitesse_max, prix, nombre_portes):
        super().__init__(marque, modele, annee, vitesse_max, prix)
        self.nombre_portes = nombre_portes
        self.vitesse_actuelle = 0

    def demarrer(self):
        print("La voiture démarre.")

    def accelerer(self):
        self.vitesse_actuelle += 10
        print("La voiture accélère. Vitesse actuelle:", self.vitesse_actuelle)

    def freiner(self):
        self.vitesse_actuelle -= 10
        print("La voiture freine. Vitesse actuelle:", self.vitesse_actuelle)

    def arreter(self):
        self.vitesse_actuelle = 0
        print("La voiture s'arrête.")

    def afficher_infos(self):
        print("Marque:", self.marque)
        print("Modèle:", self.modele)
        print("Année:", self.annee)
        print("Vitesse maximale:", self.vitesse_max)
        print("Prix:", self.prix)
        print("Nombre de portes:", self.nombre_portes)
