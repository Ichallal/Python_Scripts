from Voiture_abstract1 import Voiture

# Création d'objets
voiture1 = Voiture("peageat", "Clio", 2010, 180, 12000, 3)

# Appel de méthodes
voiture1.demarrer()
voiture1.accelerer()
voiture1.freiner()
voiture1.arreter()
voiture1.afficher_infos()