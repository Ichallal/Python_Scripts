from abc import ABC, abstractmethod
class Vehicule(ABC):
    @abstractmethod
    def __init__(self, marque, modele, annee, vitesse_max, prix):
        self.marque = marque
        self.modele = modele
        self.annee = annee
        self.vitesse_max = vitesse_max
        self.prix = prix

    @abstractmethod
    def demarrer(self):
        pass

    @abstractmethod
    def accelerer(self):
        pass

    @abstractmethod
    def freiner(self):
        pass

    @abstractmethod
    def arreter(self):
        pass

    @abstractmethod
    def afficher_infos(self):
        pass
